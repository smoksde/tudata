import java.util.PriorityQueue;

public class HeapSort {

    public static void heapSort(Comparable[] a){
        PriorityQueue<Comparable> x = new PriorityQueue<Comparable>();
        for (Comparable c:a
             ) {
            x.add(c);
        }
        for(int i = 0; i < a.length; i++){
            a[i] = x.poll();
        }

    }

    public static void main(String[] args) {
        Integer[] a = {7,5,4,4,21,2345,0,-1};
        heapSort(a);
        for (Integer i: a
             ) {
            System.out.println(i);
        }
    }
}
