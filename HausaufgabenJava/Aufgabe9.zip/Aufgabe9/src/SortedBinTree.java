import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;

public class SortedBinTree <T extends Comparable>{
    Node<T> root;

    public SortedBinTree(){
        root = null;
    }

    public void insertInOder(T v){
        if (root == null) {
            root = new Node(v);
            return;
        }
        assert(root != null);
        insertInOrder(v, root);
    }

    private void insertInOrder(T v, Node<T> n){
        if (v.compareTo(n.val) <= 0) {
            if (n.left == null){
                n.left = new Node<>(v);
                return;
            } else {
                insertInOrder(v, n.left);
            }
        } else {
            if (n.right == null){
                n.right = new Node<>(v);
                return;
            } else {
                insertInOrder(v, n.right);
            }
        }
    }

    public List<T> toOrderedList(){
        return toOrderedList(root);
    }

    private List<T> toOrderedList(Node<T> n){
        if (n == null){
            return new LinkedList<T>();
        } else{
            List<T> l = toOrderedList(n.left);
            List<T> r = toOrderedList(n.right);
            r.add(0,n.val);
            r.addAll(0,l);
            return r;
        }
    }

    public List<T> getLeaves(){
        return getLeaves(root);
    }
    private List<T> getLeaves(Node<T> n){

        if (n == null) {
            return new LinkedList<T>();
        }
        assert(n != null);

        List<T> l = getLeaves(n.left);
        List<T> r = getLeaves(n.right);
        r.addAll(0, l);
        return r;

    }

    public List<T> getNodesOnLevel(int i){
        assert(i >= 0) : "no negative levels please";
        if (i <0 ) return null;
        return getNodesOnLevel(root, i );
    }

    private List<T> getNodesOnLevel(Node<T> n, int i){
        if (i == 0 ) {
            List<T> res = new LinkedList<T>();
            if (n != null) res.add(n.val);
            return res;
        }
        assert (i > 0);
        if (n!= null){
            List<T> l = getNodesOnLevel(n.left,i-1);
            List<T> r = getNodesOnLevel(n.right,i-1);
            if (r != null && l!= null) {
                r.addAll(0,l);
                return r;
            } else {
                return l;
            }

        }
        // 'unreachable'
        assert(false) : "this should not be ";
        return null;
    }

    public String toString(){
        if (root != null){
            return "["+root.toString()+"]";
        } else {
            return "ø";
        }
    }

    public static void main(String[] args) {
        SortedBinTree<Integer> t = new SortedBinTree<>();
        Integer[] x = {4,7,8,9,2,1};
        for ( int i : x){
            t.insertInOder(i);
        }
        System.out.println(t);

        for (int i: t.toOrderedList()
        ) {
            System.out.print(i);
        }
        System.out.println();

        for (int i: t.getNodesOnLevel(3)
        ) {
            System.out.print(i);
        }
        System.out.println();
    }

}

class Node<T>{
    T val;
    Node<T> left;
    Node<T> right;

    Node(T v){
        val = v;
        left = null;
        right = null;
    }

    Node(T v, Node<T>l, Node<T>r){
        val = v;
        left = l;
        right = r;
    }

    public String toString(){
        return val + ":" +
                (left==null?"ø":"["+left.toString()+"]")
                + "," +
                (right==null?"ø":"["+right.toString()+"]")
                ;
    }

    void addLeavesBelow(HashSet<Node<T>> s){
        if (this.left == null && null == this.right){
            s.add(this);
            return;
        }
        if (this.left != null) left.addLeavesBelow(s);
        if (this.right != null) right.addLeavesBelow(s);
    }
}
