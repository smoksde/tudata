import java.util.List;

public class ComparableSortedBinTree<T extends Number> extends SortedBinTree implements Comparable<ComparableSortedBinTree<T>>{

    @Override
    public int compareTo(ComparableSortedBinTree<T> csbt) {
        return (int) (Math.round(this.sum() - csbt.sum()));
    }
    public double sum(){
        double res = 0;
        List<T> l = toOrderedList();

        for (T x:l
             ) {
            res = res + x.doubleValue();
        }
        return res;
    }

}
