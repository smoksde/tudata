import java.util.HashSet;
import java.util.Stack;

public class Tree<T> {
    protected Node<T> root = null;

    public Tree(Node node) {
        root = node;
    }

    public Tree() { }

    public String toString(){
        if (root != null){
            return "["+root.toString()+"]";
        } else {
            return "ø";
        }
    }

    public HashSet<Node<T>> getLeaves(){
        if (root == null) return null;
        assert(root != null);
        HashSet<Node<T>> res = new HashSet<Node<T>>();
        root.addLeavesBelow(res);
        return res;
    }

    static public Tree<Integer> parseTree(String s){
        Stack<Object> stack = new Stack();

        for(int i = 0; i < s.length();i++){
            char next = s.charAt(i);
            switch (next){
                case 'ø' : // empty node
                    stack.push((Node<Integer>) null);
                    break;
                case '[' : break;
                case ']' : // build node
                    Node<Integer> r = (Node<Integer>) stack.pop();
                    Node<Integer> l = (Node<Integer>) stack.pop();
                    Integer val = (Integer) stack.pop();
                    stack.push(new Node(val,l,r));
                case ',' : break; // just for looks
                default: // now we have an Integer to parse
                    int j = i;
                    char c; do c = s.charAt(++j); while( c!=':');
                    int z = Integer.parseInt(s,i,j,10);
                    stack.push((Integer)z);
                    i = j;
            }
        }
        return new Tree( (Node<Integer>) stack.pop());
    }



    public static void main(String[] args) {
        Node<Integer> r = new Node(2,
                new Node(8,null,
                        new Node(1,null,null
                        )
                ),
                null)
                ;
        Node<Integer> l =
                new Node(10,
                        new Node(5,null,null),
                        null)
                ;
        Tree t = new Tree(new Node(15,l,r));

        System.out.print(t);



        HashSet<Node<Integer>> m = t.getLeaves();
        for(Node n : m){
            System.out.print(n);
        }

        Tree x = parseTree(t.toString());
        System.out.print(x);


    }

}



enum Two{
    Z,
    O,
    M,
    N
}