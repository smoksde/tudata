public enum MyState {
    THINKING,
    HUNGRY
}
