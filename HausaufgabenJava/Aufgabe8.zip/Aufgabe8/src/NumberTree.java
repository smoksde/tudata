public class NumberTree<T extends Number> extends Tree{

    public double weight() {
        if (root == null) return 0;
        double res = 0;
        // implement
        res = weight(root);
        return res;
    }

    double weight(Node<T> n){
        double res = n.val.doubleValue();
        if (n.left != null){
            res = res + (weight(n.left));
        }
        if (n.right != null){
            res = res + (weight(n.right));
        }
        return res;
    }

    NumberTree(Node<T> n){
        super();
        root  = n;
    }

    public static void main(String[] args) {
        Node r = new Node(2,
                new Node(8,null,
                        new Node(1,null,null
                        )
                ),
                null)
                ;
        Node l =
                new Node(10,
                        new Node(5,null,null),
                        null)
                ;
        NumberTree t = new NumberTree(new Node(15,l,r));

        System.out.println("Das Gewicht des Baumes "+t+" ist "+t.weight());
    }
}







