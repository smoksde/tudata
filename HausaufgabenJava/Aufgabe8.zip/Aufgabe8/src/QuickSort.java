public class QuickSort {
    public static void quickSort(int[] a){
        quickSortRange(a,0,a.length-1);
    }
    private static void swap(int[]a, int i, int j ){
        int tmp = a[i];
        a[i] = a[j];
        a[j] = tmp;
    }
    private static Node<Integer> quickSortRange(int[] a,int i,int j){
        assert(i <= j) : "i>j last index is before first index "+i+","+j+" -- no good!";
        int length = j-i+1;
        switch (length){
            case 1: return new Node(a[i],null,null);
            case 2: if (a[i] > a[j]){
                swap(a,i,j);
            }
                return new Node(a[i],null,new Node(a[j],null,null));
            default: break;
        }
        int middle = i+(length/2);
        int pivot = a[middle];
// move occurrence of the pivot value to the front
        swap(a,i,middle);
// _divide_ the portion of the array
        int l = i+1;
        int r = j;
        while(l<r) {
            while (a[l] <= pivot && l < r) {
                l++;
            }
            while (a[r] >= pivot && l < r) {
                r--;
            }
            assert (l==r || (a[l] > pivot && a[r]<pivot));
            if (l!= r){
                swap(a,l,r);
            }
        }
        assert(l==r);
// there is this special case to take care of
        if (a[l] > pivot ){ l--; }
// move pivot in the right spot ...
        swap(a,i,l);
// ... and _conquer_
        assert(l>=i); Node<Integer> left = l>i?
                quickSortRange(a,i,l-1):
                null; // we have pivot = a[l]=a[i]
        assert(l<=j); Node<Integer> right = l<j?
                quickSortRange(a,l+1,j):
                null; // we have pivot = a[l]=a[j]
        return new Node(pivot,left,right);
    }
    public static Tree<Integer> quicksort(int[] a){
        return new Tree(quickSortRange(a,0,a.length-1));
    }

    public static void main(String[] args) {
        int[] a = {1, 3, 6, 4, 5, 8, 2, 7};
        Tree<Integer> baum = QuickSort.quicksort(a);
        System.out.println(baum);
    }
}