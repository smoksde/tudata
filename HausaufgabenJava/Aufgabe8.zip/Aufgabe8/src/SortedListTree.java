import java.util.List;

public class SortedListTree {
    private ListTreeNode<Integer> root = null;
    private int innerLength = 2;

    public SortedListTree(int length){
        innerLength = length;
    }

    // implement `insert`, `findNode`, and `toString`

}

class ListTreeNode<T>{
    public final T val;
    public java.util.List<ListTreeNode<T>> children = null;

    ListTreeNode(T val, List<ListTreeNode<T>> c) {
        this.val = val;
        children = c;
    }
}