import java.util.HashSet;

public class UndirectedForest<T> {
    private HashSet<List<T>> forest = null;

    public HashSet<ListEl<T>> getRoots(){
        HashSet<ListEl<T>> roots = new HashSet<>();
        for(List<T> l : forest){
            roots.add(l.last());
        }
        return roots;
    }

    public boolean isTree(){
        if (forest.isEmpty()) return false;
        HashSet<ListEl<T>> roots = getRoots();
        if (roots.contains(null)) return false;
        return( 1 == roots.size()) ;
    }




}


class List<T>{
    ListEl<T> head = null;

    List(){}

    List(ListEl<T> el){
        head = el;
    }

    ListEl<T> last(){
        if (head == null) return null;
        ListEl<T> el = head;
        while(el.next != null){
            el = el.next;
        };
        return el;
    }
}

class ListEl<T> {
    ListEl<T> next;
    T val;

    // feel free to add methods

    void insertAfter(ListEl<T> e){
        if (e != null) {
            this.next = e.next;
            e.next = this;
        } else {
            System.out.println("uh, ooo ... ");
        }
    }

    ListEl(ListEl n, T v){
        next = n;
        val = v;
    }

}

