import java.lang.Math;

import static java.lang.Thread.sleep;

public class ListInserter implements Runnable{
    private List<Integer> list;
    Thread t;

    ListInserter(List<Integer> l, Thread thread){
        list = l;
        t = thread;
    }

    @Override
    public void run() {
        try {
            sleep(10);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        try {
            t.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (NullPointerException e) {
            // hack
        }
        synchronized (list){
            ListEl<Integer> head = list.getHead();
            ListEl<Integer> e = new ListEl<Integer>((Integer) (int)(100 * Math.random()), head);
            if (head != null) {
                synchronized (head) {
                    list.setHead(e);
                }
            } else {
                list.setHead(e);
            }
            System.out.println(this+" insterted "+e.val+".");
        }
    }
}
