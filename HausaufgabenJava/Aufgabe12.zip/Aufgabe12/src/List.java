public class List<T> {
    private volatile ListEl<T> head;
    public ListEl<T> getHead() {
        return head;
    }
    public void setHead(ListEl<T> head) {
        this.head = head;
    }

    public List(){
        head = null;
    }

    public String toString(){
        if (head == null){
            return "[]";
        } else {
            return "[" + head.toString();
        }
    }


    public static void main(String[] args) {
        int count = 40;
        List<Integer> l = new List();
        Thread[] inserters = new Thread[count];
        Thread[] bubblers = new Thread[count];
        Thread t = null;
        for(int i = 0; i < count; i++){
            inserters[i] = new Thread(new ListInserter(l,t));
            bubblers[i] = new Thread(new ListBubbler(l,inserters[i]));
            t = inserters[i];
        }
        for(int i = 0; i < count; i++){
            inserters[i].start();
            bubblers[i].start();
        }
        for(int i = 0; i < count ; i++){
            try {
                bubblers[i].join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        System.out.println(l);
    }
}

class ListEl<T>{
    T val;
    ListEl<T> next;

    ListEl(T v, ListEl<T> n){
        val = v;
        next = n;
    }

    @Override
    public String toString(){
        String res = "" + val;
        if (next==null)
            res = res +"]";
        else
            res = res + ", "+next;
        return res;
    }
}
