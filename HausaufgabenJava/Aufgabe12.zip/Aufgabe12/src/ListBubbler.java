public class ListBubbler implements Runnable{
    private List<Integer> list;
    private Thread inserter;

    ListBubbler(List<Integer> l, Thread t){
        list = l;
        inserter=t;
    }

    @Override
    public void run() {
        try {
            inserter.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        Boolean first = true;
        for (ListEl<Integer> el = list.getHead(); el != null && el.next != null ; el = el.next){
            if (el != null && el.next != null) {
                synchronized (el){
                    synchronized (el.next){
                        if (el.val > el.next.val){
                            Integer tmp = el.val;
                            el.val = el.next.val;
                            el.next.val = tmp;
                        } else {
                            if (first){
                                System.out.println("New element " + el.val + " was \"sorted\" by " + this+".");
                                first = false;
                            }
                        }
                    }
                }
            }
        }
    }
}
