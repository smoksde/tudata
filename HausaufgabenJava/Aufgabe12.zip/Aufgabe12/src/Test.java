public class Test {
    public static void main(String[] args) {
        Integer a = 1;
        Integer b = 2 ;

        X x = new X(a,b);

        Xthread t = new Xthread(x);

        synchronized (x){
            t.start();
            try {
                t.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}

class X{
    Integer a;
    Integer b;

    X(Integer i, Integer j){
        a = i;
        b = j;
    }
}

class Xthread extends Thread{
    X obj;

    Xthread(X x){
        obj = x;
    }

    public void run(){
        synchronized (obj.a){
            System.out.println(obj.a);

        }
    }

}