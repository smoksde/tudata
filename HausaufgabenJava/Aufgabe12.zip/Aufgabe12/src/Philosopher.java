import java.lang.Math;
public class Philosopher extends Thread{
    public final Object chopstick;
    final Boolean meFirst;
    private MyState state = MyState.THINKING;
    Philosopher next;

    public Philosopher(Object chopstick, Boolean whofirst) {
        this.chopstick = chopstick;
        meFirst = whofirst;
    }

    @Override
    public void run() {
        while(true){
            if (state == MyState.THINKING){
                try {
                    System.out.println(this + " has a new thought.");
                    this.sleep((int)(100 * Math.random()));
                    state = MyState.HUNGRY;
                } catch (InterruptedException e) {
                    System.out.println("errr, what?");
                }
            } else {
                if (meFirst){
                    synchronized (this.chopstick){
                        try {
                            this.sleep((int)(100 * Math.random()));
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                        synchronized (next.chopstick){
                            try {
                                System.out.println(this + " is starting to eat.");
                                this.sleep(1);
                                state = MyState.THINKING;
                            } catch (InterruptedException e) {
                                System.out.println("yes, what?");
                            }
                        }
                    }
                } else {
                    synchronized (next.chopstick){
                        try {
                            this.sleep(1000);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                        synchronized (this.chopstick) {
                            try {
                                System.out.println(this + " is eating.");
                                this.sleep(1);
                            } catch (InterruptedException e) {
                                System.out.println("yes, what?");
                            }
                        }
                        state = MyState.THINKING;
                    }
                }
            }
        }
    }

    public static void main(String[] args) {
        final int count = 10;
        Philosopher[] philosophers = new Philosopher[count];

        for(int i=0; i< count; i++){
            if (i % 2 >0) {
                philosophers[i] = new Philosopher(i, true);
            } else {
                philosophers[i] = new Philosopher(i, false);
            }
        }
        philosophers[count-1].next = philosophers[0];
        for(int i=0; i<count-1; i++) {
            philosophers[i].next = philosophers[i+1];
        }
        for(int i=0; i< count; i++){
            philosophers[i].start();
        }
    }
}




