package de.tuberlin.mcc.prog1.logistics.gui;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.ComponentOrientation;
import java.awt.Composite;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GraphicsConfiguration;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Insets;
import java.awt.Paint;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.ScrollPane;
import java.awt.Shape;
import java.awt.Stroke;
import java.awt.RenderingHints.Key;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.font.FontRenderContext;
import java.awt.font.GlyphVector;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;
import java.awt.image.BufferedImageOp;
import java.awt.image.ImageObserver;
import java.awt.image.RenderedImage;
import java.awt.image.renderable.RenderableImage;
import java.text.AttributedCharacterIterator;
import java.util.ArrayList;
import java.util.Map;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.Border;

import de.tuberlin.mcc.prog1.logistics.DeliveryManager;
import de.tuberlin.mcc.prog1.logistics.Location;
import de.tuberlin.mcc.prog1.logistics.LogisticsManager;
import de.tuberlin.mcc.prog1.logistics.deliveries.Delivery;
import de.tuberlin.mcc.prog1.logistics.deliveries.Letter;
import de.tuberlin.mcc.prog1.logistics.deliveries.Parcel;

public class LogisticsSimulator extends JFrame {

	Font normalFont = new Font(Font.SERIF, Font.PLAIN, 26);
	Font mapBoldFont = new Font(Font.SANS_SERIF, Font.BOLD, 18);
	Font mapLocationNameFont = new Font(Font.SANS_SERIF, Font.PLAIN, 18);
	Font deliveryFont = new Font(Font.SERIF, Font.PLAIN, 26);
	
	Color locationColor = Color.decode("#000000");
	Color santaRed = Color.decode("#ff0000");
	Color santaWhite = Color.decode("#fff7f7");
	Color santaOrange = Color.decode("#fcd27e");
	Color santaGray = Color.decode("#adaca9");
	
	DeliveryManager deliveryManager;
	
	JPanel mapPanel;
	JLabel mapImage;	
	JScrollPane deliveryPanel;
	
	private static final long serialVersionUID = 7795453049253322895L;
	
	public LogisticsSimulator(DeliveryManager deliveryManager) {
		this.deliveryManager = deliveryManager;
		this.setSize(800, 600);
		this.setExtendedState(JFrame.MAXIMIZED_BOTH);
		this.setTitle("Logistics simulation");
		
		this.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				LogisticsManager.stop();
				System.exit(0);
			}
		});
		
		addMainGuiComponents();		
		this.setVisible(true);
	}
		
	private void addMainGuiComponents() {
		this.setLayout(new GridBagLayout());
		GridBagConstraints gbc = new GridBagConstraints();
		
		JPanel mainPanel = new JPanel(new GridBagLayout());
		gbc.fill = GridBagConstraints.BOTH;
		gbc.weightx = 1.0;
		gbc.weighty = 1.0;
		this.add(mainPanel, gbc);
		
		mapPanel = new JPanel();
		gbc = new GridBagConstraints();
		gbc.fill = GridBagConstraints.BOTH;
		gbc.weightx = 0.6;
		gbc.weighty = 1.0;
		mainPanel.add(mapPanel, gbc);
		
		deliveryPanel = new JScrollPane(getDeliveriesPanel(), JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		deliveryPanel.setMinimumSize(new Dimension(300, 100));
		gbc = new GridBagConstraints();
		gbc.gridx = 1;
		gbc.fill = GridBagConstraints.BOTH;
		gbc.weightx = 0.4;
		gbc.weighty = 1.0;
		mainPanel.add(deliveryPanel, gbc);
		
	}
	
	public JPanel getDeliveriesPanel() {		
		JPanel panel = new JPanel(new GridBagLayout());
		GridBagConstraints gbc;
		int i = 0;
		for (Delivery d : deliveryManager.getDeliveries()) {
			if (d != null) {
				gbc = new GridBagConstraints();
				gbc.gridy = i;
				gbc.weightx = 1;
				gbc.fill = GridBagConstraints.BOTH;
				panel.add(getDeliveryPanel(d), gbc);
				i++;
			}
		}
		gbc = new GridBagConstraints();
		gbc.gridy = i;
		gbc.weightx = 1;
		gbc.weighty = 1;
		gbc.fill = GridBagConstraints.BOTH;
		panel.add(new JPanel(), gbc);
		return panel;		
	}
	
	public JPanel getDeliveryPanel(Delivery d) {
		JPanel panel = new JPanel(new GridBagLayout());
		panel.setBorder(BorderFactory.createLineBorder(Color.DARK_GRAY, 2));		
		JLabel lblFrom = new JLabel("From:");
		JLabel lblTo = new JLabel("To:");
		JLabel lblWeight = new JLabel("Weight:");
		JLabel lblPostage = new JLabel("Postage:");
		JLabel lblFromLocation = new JLabel(d.getSender().getName());
		JLabel lblToLocation = new JLabel(d.getReceiver().getName());
		JLabel lblWeightDelivery = new JLabel("" + d.getWeight() + " kg");
		int euro = d.getPostage()/100;
		String cent = "" + (d.getPostage() % 100);
		if (cent.length() == 1) {
			cent = "0" + cent;
		}
		JLabel lblPostageDelivery = new JLabel("" + euro + "." + cent + " �");
		lblFrom.setFont(deliveryFont);
		lblTo.setFont(deliveryFont);
		lblWeight.setFont(deliveryFont);
		lblPostage.setFont(deliveryFont);
		lblFromLocation.setFont(deliveryFont);
		lblToLocation.setFont(deliveryFont);
		lblWeightDelivery.setFont(deliveryFont);
		lblPostageDelivery.setFont(deliveryFont);
		
		
		GridBagConstraints gbc = new GridBagConstraints();
		gbc.weightx = 1;
		gbc.fill = GridBagConstraints.HORIZONTAL;
		panel.add(lblFrom, gbc);
		gbc.gridx = 1;
		panel.add(lblFromLocation, gbc);
				
		gbc.gridx = 0;
		gbc.gridy = 1;
		panel.add(lblTo, gbc);		
		gbc.gridx = 1;
		panel.add(lblToLocation, gbc);
		
		gbc.gridx = 0;
		gbc.gridy = 2;
		panel.add(lblWeight, gbc);		
		gbc.gridx = 1;
		panel.add(lblWeightDelivery, gbc);
		
		gbc.gridx = 0;
		gbc.gridy = 3;
		panel.add(lblPostage, gbc);		
		gbc.gridx = 1;
		panel.add(lblPostageDelivery, gbc);
		
		
		if (d instanceof Letter) {
			Letter l = (Letter) d;			
			JLabel lblRegistered = new JLabel("Registered:");
			lblRegistered.setFont(deliveryFont);
			JLabel lblRegisteredValue = new JLabel(l.isRegisteredLetter()?"YES":"NO");
			lblRegisteredValue.setFont(deliveryFont);
			gbc.gridx = 0;
			gbc.gridy = 4;
			panel.add(lblRegistered, gbc);		
			gbc.gridx = 1;
			panel.add(lblRegisteredValue, gbc);			
		}
		if (d instanceof Parcel) {
			Parcel p = (Parcel) d;
			
			JLabel lblCategory = new JLabel("Category:");
			lblCategory.setFont(deliveryFont);
			JLabel lblCategoryValue = new JLabel("" + p.getCategory());
			lblCategoryValue.setFont(deliveryFont);
			gbc.gridx = 0;
			gbc.gridy = 4;
			panel.add(lblCategory, gbc);		
			gbc.gridx = 1;
			panel.add(lblCategoryValue, gbc);
			
			JLabel lblExpress = new JLabel("Express:");
			lblExpress.setFont(deliveryFont);
			JLabel lblExpressValue = new JLabel(p.isExpressDelivery()?"YES":"NO");
			lblExpressValue.setFont(deliveryFont);
			gbc.gridx = 0;
			gbc.gridy = 5;
			panel.add(lblExpress, gbc);		
			gbc.gridx = 1;
			panel.add(lblExpressValue, gbc);
			
			JLabel lblInsurance = new JLabel("Insurance:");
			lblInsurance.setFont(deliveryFont);
			JLabel llblInsuranceValue = new JLabel(p.isTransportInsurance()?"YES":"NO");
			llblInsuranceValue.setFont(deliveryFont);
			gbc.gridx = 0;
			gbc.gridy = 6;
			panel.add(lblInsurance, gbc);		
			gbc.gridx = 1;
			panel.add(llblInsuranceValue, gbc);
			
			JLabel lblRedirection = new JLabel("Redirection:");
			lblRedirection.setFont(deliveryFont);
			JLabel lblRedirectionValue = new JLabel(p.isRedirection()?"YES":"NO");
			lblRedirectionValue.setFont(deliveryFont);
			gbc.gridx = 0;
			gbc.gridy = 7;
			panel.add(lblRedirection, gbc);		
			gbc.gridx = 1;
			panel.add(lblRedirectionValue, gbc);			
		}
		
		return panel;
	}
	
	public void UpdateGUI() {
		updateImage();
		updateDeliveriesPanel();
	}
	
	private void updateImage() {
		Image generated = getCurrentImage();
		int w = mapPanel.getWidth();
		if (mapPanel.getHeight() < w) {
			w = mapPanel.getHeight();
		}		
		Image scaled = generated.getScaledInstance(w, w, Image.SCALE_FAST);
		
		
		if (mapImage == null) {
			mapImage = new JLabel(new ImageIcon(scaled));
			mapPanel.add(mapImage);
		} else {
			mapImage.setIcon(new ImageIcon(scaled));
		}
		mapImage.updateUI();
		
	}
	
	private void updateDeliveriesPanel() {
		deliveryPanel.setViewportView(getDeliveriesPanel());
		deliveryPanel.updateUI();
	}

	private Image getCurrentImage() {
		Dimension d = deliveryManager.getDimension();
		int w = d.width * 10;
		int h = d.height * 10;
		BufferedImage image = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
		Graphics2D g = image.createGraphics();		
		g.setColor(Color.WHITE);
		g.fillRect(0, 0, w, h);
		
		g.setColor(Color.BLACK);
		g.setStroke(new BasicStroke(3));
		g.setFont(normalFont);
		for (Location l : deliveryManager.getLocations()) {
			drawLocation(g, l);
		}
		
		for (SantaController sc : SantaController.getSantas()) {
			drawSanta(g, sc);
		}
		
		g.dispose();
		return image;
	}
	
	private void drawLocation(Graphics2D g, Location l) {
		if (l != null) {
			int x = l.getxPosition() * 10;
			int y = l.getyPosition() * 10;
			g.drawOval(x-15, y-15, 30, 30);
			String count = "" + deliveryManager.countDeliveriesForLocation(l.getId());
			g.setFont(mapBoldFont);
			g.drawChars(count.toCharArray(), 0, count.length(), x-5, y+6);
			g.setFont(mapLocationNameFont);
			g.drawChars(l.getName().toCharArray(), 0, l.getName().length(), x + 20, y+10);
		}
	}
	
	private void drawSanta(Graphics2D g, SantaController sc) {
		g.setColor(santaOrange);
		int x = sc.getX() * 10;
		int y = sc.getY() * 10;		
		g.fillOval(x-15, y-15, 30, 30);
		g.setColor(santaRed);
		g.fillArc(x-30, y-65, 60, 60, 250, 40);
				
		g.setColor(santaGray);
		g.drawLine(x-8, y+5, x, y+8);
		g.drawLine(x, y+8, x+8, y+5);
		g.drawLine(x-8, y, x-6, y);
		g.drawLine(x+6, y, x+8, y);
		
		g.setColor(Color.black);
		int size = sc.getInventory().size();
		String text =  size + " deliveries";
		if (size == 1) {
			text =  size + " delivery";
		}
		g.drawChars(text.toCharArray(), 0, text.length(), x+20, y+20);
	}
	
}
