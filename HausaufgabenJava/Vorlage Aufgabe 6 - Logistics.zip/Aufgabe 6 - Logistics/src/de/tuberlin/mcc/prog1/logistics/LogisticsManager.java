package de.tuberlin.mcc.prog1.logistics;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

import de.tuberlin.mcc.prog1.logistics.deliveries.Delivery;
import de.tuberlin.mcc.prog1.logistics.deliveries.Letter;
import de.tuberlin.mcc.prog1.logistics.deliveries.Parcel;
import de.tuberlin.mcc.prog1.logistics.gui.LogisticsSimulator;
import de.tuberlin.mcc.prog1.logistics.gui.SantaController;
import de.tuberlin.mcc.prog1.logistics.gui.Util;

public class LogisticsManager {
		
	/**
	 * Available locations.
	 */
	public static Location[] locations = new Location[30];
	
	/**
	 * Simulation running
	 */
	private static boolean running = true;

	/**
	 * Starts Manager.
	 * @param args - not defined yet
	 */
	public static void main(String[] args) {
		
		//Create and add some locations.
		locations[0] = new Location("Berlin", 75, 25);
		locations[1] = new Location("Hamburg", 25, 10);
		locations[2] = new Location("Koeln", 10, 50);
		locations[3] = new Location("Muenchen", 60, 70);
		locations[4] = new Location("Frankfurt", 25, 60);
		locations[5] = new Location("Stuttgart", 20, 80);
		
		//Create a manager for deliveries.
		DeliveryManager deliveryManager = new DeliveryManager();
		// Register some deliveries from inputdata.csv
		deliveryManager.registerDeliveries(preloadInitialDataSet());
		
		//Add some Santas
		int numberOfSantas = 1;
		for (int i = 0; i < numberOfSantas; i++) {
			new SantaController(deliveryManager);
		}
		
		//Run user interface
		LogisticsSimulator sim = new LogisticsSimulator(deliveryManager);
		
		while (running) {		
			sim.UpdateGUI();
			SantaController.performSantaOperationForEverySanta();
			Util.sleep(50);
		}		
	}
	
	/**
	 * Stops simulation
	 */
	public static void stop() {
		running = false;
	}
	
	/**
	 * Loads an initial data set from the file inputdata.csv
	 * 
	 * * @return a Delivery[], will never be null but may have length 0
	 */
	public static Delivery[] preloadInitialDataSet() {
		BufferedReader br = null;
		try {
			//Create reader to read input files
			br = new BufferedReader(new FileReader("inputdata.csv"));
			//Create list to store data from file
			ArrayList<Delivery> deliveries = new ArrayList<Delivery>();
			String line;
			//Read each line from file
			while ((line = br.readLine()) != null) {
				//Split line by ';'
				String[] splits = line.split(";");
				if (splits.length == 5 && "L".equals(splits[0])) {
					//Assign values
					int senderID = Integer.parseInt(splits[1]);
					int receiverID = Integer.parseInt(splits[2]);
					Location sender = DeliveryManager.getLocationById(senderID);
					Location receiver = DeliveryManager.getLocationById(receiverID);
					double weight = Double.parseDouble(splits[3]);
					boolean registered = Boolean.parseBoolean(splits[4]);
					//Create letter
					if (sender != null && receiver != null) {
						Letter l = new Letter(sender, receiver, weight, registered);
						deliveries.add(l);
					}
				} else {
					if (splits.length == 10 && "P".equals(splits[0])) {
						//Assign values
						int senderID = Integer.parseInt(splits[1]);
						int receiverID = Integer.parseInt(splits[2]);
						Location sender = DeliveryManager.getLocationById(senderID);
						Location receiver = DeliveryManager.getLocationById(receiverID);
						double weight = Double.parseDouble(splits[3]);
						
						int length = Integer.parseInt(splits[4]);
						int width = Integer.parseInt(splits[5]);
						int height = Integer.parseInt(splits[6]);
						
						boolean express = Boolean.parseBoolean(splits[7]);
						boolean insurance = Boolean.parseBoolean(splits[8]);
						boolean redirection = Boolean.parseBoolean(splits[9]);
						
						//Create parcel
						if (sender != null && receiver != null) {
							if (length > 0 && width > 0 && height > 0) {
								int[] size = {length, width, height};
								boolean[] services = {express, insurance, redirection};
								Parcel p = new Parcel(sender, receiver, weight, services, size);
								deliveries.add(p);
							}
						}
					} else {
						System.out.println("Could not process line:" + line);
					}
				}
			}
			//convert list into array
			return deliveries.toArray(new Delivery[deliveries.size()]);

		} catch (Exception e) {
			// Some failure handling
			System.out.println("There was an error while trying to load the initial data set:");
			e.printStackTrace();
			return new Delivery[0];
		} finally {
			try {
				br.close();
			} catch (IOException e) {
			}
		}
	}
	
	/**
	 * Prints available locations.
	 */
	public static void printLocations() {
		System.out.println("Locations:");
		for (Location l : locations) {
			if (l != null) {
				System.out.println(l.toString());
			}
		}
	}
	
	/**
	 * Adds a location.
	 * @param l - location to add
	 */
	public static void addLocation(Location l) {
		for (int i = 0; i < locations.length; i++) {
			if (locations[i] == null) {
				locations[i] = l;
				return;
			}
		}
		System.out.println("Unable to add " + l.toString() + "(to many locations).");
	}	

}
