package de.tuberlin.mcc.prog1.logistics;

import java.awt.Dimension;

import de.tuberlin.mcc.prog1.logistics.deliveries.Delivery;

public class DeliveryManager {
	
	/**
	 * Dimension of map
	 */
	Dimension dim = new Dimension(100, 100);
	
	/**
	 * Registered deliveries
	 */
	Delivery[] deliveries = new Delivery[0];
	/**
	 * Available locations
	 */
	static Location[] locations =  LogisticsManager.locations;
	
	/**
	 * Registers given deliveries
	 * @param deliveries - deliveries to register
	 */
	public void registerDeliveries(Delivery... deliveries) {
		if (deliveries == null || deliveries.length == 0) {
			return;
		}
		Delivery[] oldDeliveries = this.deliveries;
		Delivery[] newDeliveries = new Delivery[oldDeliveries.length + deliveries.length];
		
		for (int i = 0; i < newDeliveries.length; i++) {
			if (i < oldDeliveries.length) {
				newDeliveries[i] = oldDeliveries[i];
			} else {
				newDeliveries[i] = deliveries[i-oldDeliveries.length];
			}
		}
		this.deliveries = newDeliveries;
		
		//Remove leading null values in this.deliveries here		
	}
	
	/**
	 * Removes a given Delivery from registered deliveries
	 * @param delivery - delivery to remove
	 * @return deleted delivery or null (if given delivery wasn't in array)
	 */
	public Delivery removeDelivery(Delivery delivery) {
		return null;
	}
	
	/**
	 * Counts registered deliveries for location with given locationID 
	 * (sender ID of delivery equals locationID)
	 * @param locationID - locationID of sender
	 * @return number of deliveries at given location 
	 */
	public int countDeliveriesForLocation(int locationID) {
		return 0;
	}
	
	/**
	 * Updates the receiver of a delivery by location id.
	 * @param index - Index position of delivery
	 * @param locationId - Id of location
	 */
	void setReceiverForDelivery(int index, int locationId) {
		if (index >= 0 && index < deliveries.length) {
			Location receiver = getLocationById(locationId);
			if (receiver != null) deliveries[index].setReceiver(receiver);
		}
	}
	
	/**
	 * Searches in Location[] locations (see above) for a location with given ID. 
	 * @param id - Id of location to look up
	 * @return location with given id or null if there is no such location
	 */
	public static Location getLocationById(int id) {
		for (Location l : locations) {
			if (l != null && l.getId() == id) {
				return l;
			}
		}
		return null;
	}	
	
	/**
	 * Prints all registered deliveries.
	 */
	public void printDeliveries() {
		System.out.println("Registered Deliveries:");
		for (int i = 0; i < deliveries.length; i++) {
			if (deliveries[i] != null) {
				System.out.println("[" + i + "]: " + deliveries[i].toString());
			}
		}
	}
	
	/**
	 * Returns array of locations
	 * @return array of locations
	 */
	public Location[] getLocations() {
		return locations;
	}
	
	/**
	 * Returns registered deliveries
	 * @return array with registered deliveries
	 */
	public Delivery[] getDeliveries() {
		return deliveries;
	}
	
	/**
	 * Returns dimension of map
	 * @return dimension of map
	 */
	public Dimension getDimension() {
		return dim;
	}

}
