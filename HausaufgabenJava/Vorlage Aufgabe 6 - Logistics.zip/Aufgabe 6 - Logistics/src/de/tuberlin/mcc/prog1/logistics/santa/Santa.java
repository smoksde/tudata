package de.tuberlin.mcc.prog1.logistics.santa;

import de.tuberlin.mcc.prog1.logistics.deliveries.Delivery;

public class Santa {
	
	/**
	 * Computes next operation for santa
	 * @param x - current x position
	 * @param y - current y position
	 * @param registeredDeliveries - current array with available deliveries
	 * @param inventory - current inventory of santa 
	 * @return computed operation
	 */
	public String computeNextOperation(int x, int y, Delivery[] registeredDeliveries, Delivery[] inventory) {
		//N - move north
		//S - move south
		//W - move west
		//E - move east
		//H - Hold, no action 
		//G 4 - Get delivery with index 4 (registeredDeliveries)
		//D 2 - Deliver delivery with index 2 (inventory)
		if (y == 0) {
			return "E";
		}
		return "N";
	}
}
