package de.tuberlin.mcc.prog1.logistics.deliveries;

import de.tuberlin.mcc.prog1.logistics.DeliveryManager;
import de.tuberlin.mcc.prog1.logistics.Location;

public class Parcel extends Delivery{
	
	/**
	 * Additional services
	 */
	private final boolean expressDelivery, transportInsurance, redirection;
	
	/**
	 * Category of parcel (S,M,L)
	 */
	private final char category;

	/**
	 * Creates parcel
	 * @param sender - sender of parcel
	 * @param receiver - receiver of parcel
	 * @param weight - weight of parcel
	 * @param services - additional services (express, insurance, redirection)
	 * @param size - size of parcel (l,w,g)
	 */
	public Parcel(Location sender, Location receiver, double weight, boolean[] services, int[] size) {
		super(sender, receiver, weight);
		expressDelivery = services[0];
		transportInsurance = services[1];
		redirection = services[2];
		
		int len = size[0] + size[1] + size[2];
		int vol = size[0] * size[1] * size[2];
		
		if (weight < 1 && len <= 80) {
			category = 'S';
			postage = 300;
		} else {
			if (weight < 4 && vol <= 64000) {
				category = 'M';
				postage = 500;
			} else {
				category = 'L';
				postage = 700;
			}
		}
		
		if (expressDelivery) {
			postage += 500;
		}
		if (transportInsurance) {
			postage += 600;
		}
		if (redirection) {
			postage += 700;
		}
		if (expressDelivery && transportInsurance && redirection) {
			postage *= 0.8;
		}
	}
	
	@Override
	public String toString() {
		String result = "Parcel " + category + " " + super.toString() + ", " + postage + "ct postage";
		if (expressDelivery) {
			result += ", express";
		}
		if (transportInsurance) {
			result += ", transport insurance";
		}
		if (redirection) {
			result += ", redirection";
		}
		return result;
	}
	
	@Override
	public void setReceiver(Location receiver) {
		if (redirection) {
			super.setReceiver(receiver);
		} else {
			System.out.println("No redirection service booked");
		}
	}

	/**
	 * Returns true if parcel is shipped with express delivery
	 * @return true if parcel is shipped with express delivery
	 */
	public boolean isExpressDelivery() {
		return expressDelivery;
	}

	/**
	 * Returns true if parcel is shipped with transport insurance
	 * @return true if parcel is shipped with transport insurance
	 */
	public boolean isTransportInsurance() {
		return transportInsurance;
	}

	/**
	 * Returns true if parcel is shipped with redirections service
	 * @return true if parcel is shipped with redirections service
	 */
	public boolean isRedirection() {
		return redirection;
	}

	/**
	 * Returns the category of parcel
	 * @return S,M or L
	 */
	public char getCategory() {
		return category;
	}
}
