package de.tuberlin.mcc.prog1.logistics;

public class Location {
	
	/**
	 * Name of location.
	 */
	private String name = "";
	
	/**
	 * Coordinates of location.
	 */
	private int xPosition, yPosition;
	
	/**
	 * Next free unique id.
	 */
	private static int nextid = 0;
	
	/**
	 * Id of locaiton.
	 */
	private int id = nextid++;

	/**
	 * Returns name of location
	 * @return name of location
	 */
	public String getName() {
		return name;
	}

	/**
	 * Updates name of location
	 * @param name - new name
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * Returns x-position of location
	 * @return x-position of location
	 */
	public int getxPosition() {
		return xPosition;
	}

	/**
	 * Returns y-position of location
	 * @return y-position of location
	 */
	public int getyPosition() {
		return yPosition;
	}

	/**
	 * Returns id of location
	 * @return id of location
	 */
	public int getId() {
		return id;
	}	
	
	/**
	 * Creates a location based on given parameters
	 * @param name - Name of location
	 * @param xPosition - x-Position of location
	 * @param yPosition - y-Position of location
	 * @return created location
	 */
	public Location(String name, int xPosition, int yPosition) {
		this.name = name;
		this.xPosition = xPosition;
		this.yPosition = yPosition;
	}
	
	@Override
	public String toString() {
		return "[" + id + "]: " + name + " (" + xPosition + "," + yPosition + ")"; 
	}

}
