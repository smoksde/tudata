package de.tuberlin.mcc.prog1.logistics.gui;

public class Util {
	
	public static void sleep(int sleepInMs) {
		try {
			Thread.sleep(sleepInMs);
		} catch (InterruptedException e) {
		}
	}

}
