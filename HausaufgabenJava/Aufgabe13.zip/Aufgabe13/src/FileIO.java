import java.io.*;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

public class FileIO {
    static String directory = System.getProperty("user.home");


    public static void main(String[] args) {
        BufferedReader kb
                = new BufferedReader(
                new InputStreamReader(System.in));
        System.out.print("Bitte geben Sie den Dateinnamen einer Datei mit Zahlen ein: ");
        String inputFileName = "";
        try {
            inputFileName = kb.readLine();
        } catch (IOException e) {
            e.printStackTrace();
        }

        // reading the content of file
        String absolutePath = directory + File.separator + inputFileName;
        List<Integer> l = new LinkedList<Integer>();
        try(FileInputStream fileInputStream = new FileInputStream(absolutePath)) {
            InputStreamReader in = new InputStreamReader(fileInputStream, "UTF-8");
            int charCode = 0;
            StringBuilder sb = new StringBuilder();
            do {
                charCode = in.read();
                if (',' == (char)charCode || charCode == -1){
                    // System.out.println(">"+ sb.toString() + "<");
                    Integer i = Integer.parseInt(sb.toString());
                    l.add(i);
                    sb = new StringBuilder();
                } else {
                    // System.out.println("next " + charCode);
                    if (48<=charCode && charCode <= 57)
                        sb.append((char)(charCode));
                }
            } while (charCode != -1);
        } catch (FileNotFoundException e) {
            // exception handling
        } catch (IOException e) {
            // exception handling
        }
        System.out.println(l);

        System.out.print("Bitte geben Sie den Dateinnamen zum Speichern der Liste ein: ");
        String outputFileName = "";
        try {
            outputFileName = kb.readLine();
        } catch (IOException e) {
            e.printStackTrace();
        }
        absolutePath = directory + File.separator + outputFileName;

        // Write the content in file
        try(FileWriter fileWriter = new FileWriter(absolutePath)) {
            Collections.sort(l);
            StringBuilder sb = new StringBuilder();
            for (Integer k : l){
                sb.append(k);
                sb.append(',');
            }
            if (!l.isEmpty()){
                sb.deleteCharAt(sb.length()-1);
            }
            fileWriter.write(sb.toString());
            fileWriter.close();
        } catch (IOException e) {
            // Cxception handling
        }
    }
}
