import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

public class ClientServerCommunication {
    public static void main(String[] args) {
        new Server().start();
        new Client().start();
        System.out.println("... and go!");
    }
}

class Server extends Thread{
    public void run(){
        {

            // Create server Socket
            ServerSocket ss = null;
            try {
                ss = new ServerSocket(8000);
            } catch (IOException e) {
                e.printStackTrace();
            }

            // connect it to client socket
            Socket s = null;
            try {
                s = ss.accept();
            } catch (IOException e) {
                e.printStackTrace();
            }
            System.out.println("Connection established");

            // to send data to the client
            PrintStream ps
                    = null;
            try {
                ps = new PrintStream(s.getOutputStream());
            } catch (IOException e) {
                e.printStackTrace();
            }

            // to read data coming from the client
            BufferedReader br
                    = null;
            try {
                br = new BufferedReader(
                new InputStreamReader(
                        s.getInputStream()));
            } catch (IOException e) {
                e.printStackTrace();
            }


            String str = null, str1 = null;
            List l = new LinkedList<Integer>();
            // server executes continuously
            while (true) {



                // repeat as long as the client
                // does not send a null string

                // read from client
                while (true) {
                    try {
                        str = br.readLine();
                        System.out.println("received " + str);
                    } catch (IOException e) {
                        e.printStackTrace();
                        break;
                    }


                    if (str.equals("sort")){
                        Collections.sort(l);
                        String msg = l.toString();
                        // send to client
                        ps.println(msg);

                        l = new LinkedList<Integer>();
                    } else {
                        Integer i = null;
                        try {
                            i = Integer.parseInt(str);
                            l.add(i);
                        } catch (Exception e) {
                            System.out.println("That  →" + i + " is not a number.");
                        }
                    }


                }





            } // end of while
        }
    }
}

class Client extends Thread{
    public void run(){
        // Create client socket
        Socket s = null;
        try {
            s = new Socket("localhost", 8000);
        } catch (IOException e) {
            e.printStackTrace();
        }

        // to send data to the server
        DataOutputStream dos
                = null;
        try {
            dos = new DataOutputStream(
            s.getOutputStream());
        } catch (IOException e) {
            e.printStackTrace();
        }

        // to read data coming from the server
        BufferedReader br
                = null;
        try {
            br = new BufferedReader(
            new InputStreamReader(
                    s.getInputStream()));
        } catch (IOException e) {
            e.printStackTrace();
        }

        // to read data from the keyboard
        BufferedReader kb
                = new BufferedReader(
                new InputStreamReader(System.in));
        String str = null, str1 = null;

        // repeat as long as exit
        // is not typed at client
        while (true) {

            try {
                str = kb.readLine();
            } catch (IOException e) {
                e.printStackTrace();
            }


            // send to the server
            try {
                dos.writeBytes(str + "\n");
                System.out.println("sending " + str);

            } catch (IOException e) {
                e.printStackTrace();
            }

            if (str.equals("sort")) {
                // receive from the server
                try {
                    str1 = br.readLine();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                System.out.println("Great to have this sorted. " + str1);
            }


        }



    }
}
