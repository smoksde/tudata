package main;

import exceptions.AccountException;
import exceptions.InvalidJournalEntryException;
import ledger.AccountManager;
import ledger.Accountant;

public class Main {
	
	public static void main(String[] args) {
		
		AccountManager.init();
		Accountant accountant = new Accountant();
		
		AccountManager.printAccounts();
		
		for (int i = 0; i < 100; i++) {
			
			String entry = AccountManager.getRandomJournalEntry(4);
			System.out.println(entry);
			try {
				accountant.postEntry(entry);
			} catch (InvalidJournalEntryException e) {
				e.printStackTrace();
			} catch (AccountException e) {
				e.printStackTrace();
			}			
		}	
		AccountManager.printAccounts();
		
	}

}
