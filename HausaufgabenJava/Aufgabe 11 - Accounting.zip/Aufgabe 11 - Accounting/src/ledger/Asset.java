package ledger;

public class Asset extends Account {

	public Asset(String name) {
		super(name);
	}
}
