package ledger;

public class Liability extends Account {

	public Liability(String name) {
		super(name);
	}
}
