package ledger;

public class Accountant {
	
	public void postEntry(String journalEntry) {
		
		//check syntax and import 
		
		//Ensure that debit value equals credit value
		
		//Open Accounts
		
		//Post entries
		
		//Ensure that all accounts are closed
		
	}
}
