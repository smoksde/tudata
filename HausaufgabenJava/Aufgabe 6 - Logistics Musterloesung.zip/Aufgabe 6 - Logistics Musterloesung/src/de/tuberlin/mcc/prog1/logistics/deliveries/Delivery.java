package de.tuberlin.mcc.prog1.logistics.deliveries;

import de.tuberlin.mcc.prog1.logistics.Location;

public class Delivery {
	
	/**
	 * Delivery speed.
	 */
	static final int SPEED = 1000;

	/**
	 * Sender of Delivery.
	 */
	private Location sender;
	
	/**
	 * Receiver of delivery. 
	 */
	private Location receiver;
	
	/**
	 * Time of creation.
	 */
	private long date = System.currentTimeMillis();
	
	/**
	 * Weight of delivery.
	 */
	private final double weight;
	
	/**
	 * Postage in cents.
	 */
	protected int postage;
	
	/**
	 * Returns the receiver of delivery
	 * @return receiver of delivery
	 */
	public Location getReceiver() {
		return receiver;
	}
	
	/**
	 * Updates the receiver of delivery
	 * @param receiver - new receiver
	 */
	public void setReceiver(Location receiver) {
		if (receiver != null) {
			this.receiver = receiver;
			System.out.println("Updated receiver to " + receiver.getName());
		}
	}
	
	/**
	 * Returns the weight of delivery
	 * @return weight of delivery
	 */
	public double getWeight() {
		return weight;
	}

	
	/**
	 * Returns the sender of delivery
	 * @return sender of delivery
	 */
	public Location getSender() {
		return sender;
	}
	
	/**
	 * Returns the creation time of delivery
	 * @return creation time of delivery
	 */
	public long getDate() {
		return date;
	}
	
	/**
	 * Returns the postage of delivery in cents
	 * @return postage of delivery in cents
	 */
	public int getPostage() {
		return postage;
	}
	
	/**
	 * Creates a delivery
	 * @param sender - sender of delivery
	 * @param receiver - receiver of delivery
	 * @param weight - weight of delivery
	 */
	protected Delivery(Location sender, Location receiver, double weight) {
		this.sender = sender;
		this.receiver = receiver;
		this.date = System.currentTimeMillis();
		this.weight = weight;
	}
	
	/**
	 * Returns the estimated delivery time 
	 * @return estimated delivery time
	 */
	public long getEstimatedDeliveryTime() {
		return this.date + getEstimatedDeliveryPeriod();
	}
	
	@Override
	public String toString() {
		long time = getEstimatedDeliveryTime() - System.currentTimeMillis();
		if (time < 0) {
			time = 0;
		}
		return "from " + sender.getName() + " to " + receiver.getName() 
		+ ", " + weight + "kg, arrival in " + time + "ms";
	}
	
	/**
	 * Calculates the estimated delivery period in ms
	 * @return delivery period in ms
	 */
	private long getEstimatedDeliveryPeriod() {
		return (long) getDistance() * SPEED;
	}
	
	/**
	 * Calculates the distance between sender and receiver.
	 * @return distance between sender and receiver
	 */
	private double getDistance() {
		int xdiff = sender.getxPosition() - receiver.getxPosition();
		xdiff = Math.abs(xdiff);
		int ydiff = sender.getyPosition() - receiver.getyPosition();
		ydiff = Math.abs(ydiff);
		return Math.sqrt(xdiff * xdiff + ydiff * ydiff);		
	}
	
	@Override
	public boolean equals(Object obj) {
		return this.hashCode() == obj.hashCode();
	}
	
	@Override
	public int hashCode() {
		String unique = "" + sender.getId() + receiver.getId() + weight + date;
		return unique.hashCode();
	}
}
