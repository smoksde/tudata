package de.tuberlin.mcc.prog1.logistics.gui;

import java.awt.Point;
import java.util.ArrayList;
import java.util.Random;

import de.tuberlin.mcc.prog1.logistics.DeliveryManager;
import de.tuberlin.mcc.prog1.logistics.Location;
import de.tuberlin.mcc.prog1.logistics.deliveries.Delivery;
import de.tuberlin.mcc.prog1.logistics.deliveries.Letter;
import de.tuberlin.mcc.prog1.logistics.deliveries.Parcel;
import de.tuberlin.mcc.prog1.logistics.santa.Santa;

public class SantaController {
	
	int x = 50;
	int y = 50;	
	ArrayList<Delivery> inventory = new ArrayList<>();
	DeliveryManager deliveryManager;
	Santa santa = new Santa();
	Random r = new Random();	
	static ArrayList<SantaController> santas = new ArrayList<>();
	
	public SantaController(DeliveryManager deliveryManager) {
		this.deliveryManager = deliveryManager;
		santas.add(this);
	}
	
	public void performSantaOperation() {		
		generateAndRegisterRandomDeliveries();		
		ArrayList<Delivery> registeredDeliveries = getRegisteredDeliveriesNotNull();
		Delivery[] rD = registeredDeliveries.toArray(new Delivery[registeredDeliveries.size()]);
		Delivery[] inv = inventory.toArray(new Delivery[inventory.size()]);
		String cmd = santa.computeNextOperation(x, y, rD, inv);
		if (cmd == null || cmd.length() == 0) {
			return;
		}
		System.out.println("Command: " + cmd);
		switch (cmd.charAt(0)) {
		case 'N':
			if (y > 0) {
				--y;
			}
			return;
		case 'S':
			if (y < deliveryManager.getDimension().height-1) {
				++y;
			}
			return;
		case 'E':
			if (x < deliveryManager.getDimension().width-1) {
				++x;
			}
			return;
		case 'W':
			if (x > 0) {
				--x;
			}
			return;
		case 'G':
			String[] split = cmd.split(" ");
			if (split.length > 1 && split[1].length() > 0) {
				try {
					int idx = Integer.parseInt(split[1]);
					if (idx >= 0 && idx < rD.length) {
						Delivery d = rD[idx];
						if (d.getSender().getxPosition() == x && d.getSender().getyPosition() == y) {
							deliveryManager.removeDelivery(d);
							inventory.add(d);
						}
					}
				} catch (NumberFormatException e) {
					return;
				}
			}
			return;
		case 'D':
			String[] splits = cmd.split(" ");
			if (splits.length > 1 && splits[1].length() > 0) {
				try {
					int idx = Integer.parseInt(splits[1]);
					if (idx >= 0 && idx < inv.length) {
						Delivery d = inv[idx];
						if (d.getReceiver().getxPosition() == x && d.getReceiver().getyPosition() == y) {
							inventory.remove(idx);
						}
					}
				} catch (NumberFormatException e) {
					return;
				}
			}
			return;
		default:
			return;
		}		
	}

	public int getX() {
		return x;
	}

	public int getY() {
		return y;
	}
	
	public static void performSantaOperationForEverySanta() {
		for (SantaController sc : santas) {
			sc.performSantaOperation();
		}
	}
	
	public static ArrayList<SantaController> getSantas() {
		return santas;
	}
	
	public ArrayList<Delivery> getInventory() {
		return inventory;
	}

	private void generateAndRegisterRandomDeliveries() {		
		while (getRegisteredDeliveriesNotNull().size() < 10) {
			boolean letter = r.nextBoolean();
			Location sender = getRandomLocation();
			Location receiver;
			do {
				receiver = getRandomLocation();
			} while (receiver.getId() == sender.getId());
			int weightInt = r.nextInt(3000)+100;
			double weight = weightInt;
			weight = weight / 1000;
			
			
			if (letter) {
				Letter l = new Letter(sender, receiver, weight, r.nextBoolean());
				deliveryManager.registerDeliveries(l);
			} else {
				boolean[] service = {r.nextBoolean(), r.nextBoolean(), r.nextBoolean()};
				int[] size = {r.nextInt(50)+1, r.nextInt(50)+1, r.nextInt(50)+1};
				Parcel p = new Parcel(sender, receiver, weight, service, size) ;
				deliveryManager.registerDeliveries(p);
			}
		}
	}
	
	private ArrayList<Delivery> getRegisteredDeliveriesNotNull() {
		ArrayList<Delivery> registeredDeliveries = new ArrayList<>();
		for (Delivery d : deliveryManager.getDeliveries()) {
			if (d != null) {
				registeredDeliveries.add(d);
			}
		}
		return registeredDeliveries;
	}
	
	private Location getRandomLocation() {
		int idx;
		do {
			idx = r.nextInt(deliveryManager.getLocations().length);
			if (deliveryManager.getLocations()[idx] != null ) {
				return deliveryManager.getLocations()[idx];
			}
		} while (true);
	}	
}
