package de.tuberlin.mcc.prog1.logistics.santa;

import de.tuberlin.mcc.prog1.logistics.deliveries.Delivery;

public class Santa {
	
	/**
	 * Computes next operation for santa
	 * @param x - current x position
	 * @param y - current y position
	 * @param registeredDeliveries - current array with available deliveries
	 * @param inventory - current inventory of santa 
	 * @return computed operation
	 */
	public String computeNextOperation(int x, int y, Delivery[] registeredDeliveries, Delivery[] inventory) {
		//N - move north
		//S - move south
		//W - move west
		//E - move east
		//H - Hold, no action 
		//G 4 - Get delivery with index 4 (registeredDeliveries)
		//D 2 - Deliver delivery with index 2 (inventory)
		
		//deliver items in inventory
		if (inventory.length > 0) {
			Delivery d = inventory[0];
			if (d.getReceiver().getxPosition() == x && d.getReceiver().getyPosition() == y) {
				//Deliver item
				return "D 0";
			} else {
				//Go to receiver location
				String cmd = goToLocation(x, y, d.getReceiver().getxPosition(), d.getReceiver().getyPosition());
				if (cmd.length() > 0) {
					return cmd;
				}
			}			
		}
		//Get first registered Delivery
		if (registeredDeliveries.length > 0) {
			Delivery firstDelivery = registeredDeliveries[0];
			if (firstDelivery.getSender().getxPosition() == x && firstDelivery.getSender().getyPosition() == y) {
				return "G 0";
			} else {
				//Go to sender location
				String cmd = goToLocation(x, y, firstDelivery.getSender().getxPosition(), firstDelivery.getSender().getyPosition());
				if (cmd.length() > 0) {
					return cmd;
				}
			}
		}
		
		return "H";
	}
	
	private String goToLocation(int currentX, int currentY, int targetX, int targetY) {
		if (targetX < currentX) {
			return "W";
		}
		if (targetX > currentX) {
			return "E";
		}
		if (targetY < currentY) {
			return "N";
		}				
		if (targetY > currentY) {
			return "S";
		}
		return "";
	}

}
