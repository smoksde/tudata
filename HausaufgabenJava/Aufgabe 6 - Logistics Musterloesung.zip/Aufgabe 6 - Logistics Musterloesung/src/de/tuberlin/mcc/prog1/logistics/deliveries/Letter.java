package de.tuberlin.mcc.prog1.logistics.deliveries;

import de.tuberlin.mcc.prog1.logistics.Location;

public class Letter extends Delivery {

	private final boolean registeredLetter;
	
	/**
	 * Creates Letter
	 * @param sender - sender of letter
	 * @param receiver - receiver of letter 
	 * @param weight - weight of letter
	 * @param registeredLetter - true, if registered
	 */
	public Letter(Location sender, Location receiver, double weight, boolean registeredLetter) {
		super(sender, receiver, weight);
		this.registeredLetter = registeredLetter;
		
		if (weight < 0.2) {
			postage = 70;
		} else {
			if (weight < 0.5) {
				postage = 200;
			} else {
				postage = 400;
			}
		}
		if (registeredLetter) {
			postage += 300;
		}
	}
	
	@Override
	public String toString() {
		String result = "Letter " + super.toString() + ", " + postage + "ct postage";
		if (registeredLetter) {
			result += ", registered letter";
		}
		return result;
	}

	/**
	 * Returns true if letter is a registered letter
	 * @return true if letter is a registered letter
	 */
	public boolean isRegisteredLetter() {
		return registeredLetter;
	}
}
