public class SortedIntList {
    private IntegerListEl head = null;

    public SortedIntList() {
    }

    /**
     * insert add the given int-value at the first possible position into the list
     * @param i
     */
    public void insertInOrder(int i){
        if (head == null){
            head = new IntegerListEl(null,i);
            return;
        }
        assert(head!=null);
        IntegerListEl el = head;
        while(el.val <= i && el.next != null) {
                el=el.next;
        }
        assert(el.val > i || el.next == null);
        if (el.val > i) {
            el.next = new IntegerListEl(el.next, el.val);
            el.val = i;
        } else {
            assert(el.next == null && el.val <= i);
            el.next = new IntegerListEl(null,i);
        }
    }

    /**
     * produces the sorted version of the given list
     * @param l
     */
    public SortedIntList(SinglyLinkedIntegerList l){
        int pos =0;
        Integer current = l.getValue(pos);
        if (current == null) return ;

        do {
            this.insertInOrder(current);
            pos++;
            current = l.getValue(pos);
        }
        while (current != null);
    }

    public String toString(){
        String res = "[";
        for(IntegerListEl e =head; e!=null; e=e.next){
            res = res + e.val + (e.next!=null?", ":"");
        }
        return res+"]";
    }

    public boolean checkSorted(){
        boolean res = true;
        for(IntegerListEl e = head; e!=null; e=e.next){
            if (e.next != null){
                res = res & e.val <= e.next.val;
            }
        }
        return res;
    }

    public static void main(String[] args) {

        for(int j = 0; j <1000; j++) {
            SortedIntList l = new SortedIntList();
            for (int i = 0; i < 20; i++) {
                l.insertInOrder((int) (java.lang.Math.random() * 100000));

            }
            System.out.println(l);
            assert(l.checkSorted());


        }

    }
}
