public class ListCoalescing {

    public static SinglyLinkedIntegerList merge(SinglyLinkedIntegerList fst, SinglyLinkedIntegerList snd){

        SinglyLinkedIntegerList res = new SinglyLinkedIntegerList();

        int i = 0;
        int j = 0;
        Integer first = fst.getValue(i);
        Integer second = snd.getValue(j);
        while(first != null & second != null){
            if (first <= second){
                res.append(first);
                first = fst.getValue(++i);
            } else {
                assert (second > first);
                res.append(second);
                second = snd.getValue(++j);
            }
        }
        if (first == null){
            while(second != null){
                res.append(second);
                second = snd.getValue(++j);
            }
        } else {
            assert (second == null);
            while(first != null){
                res.append(first);
                first = fst.getValue(++i);
            }
        }
        return res;
    }

    public static void main(String[] args) {
        for(int k = 0; k <1000; k++) {
            SinglyLinkedIntegerList one = new SinglyLinkedIntegerList();
            int x = 0;
            for (int i = 0; i < 15; i++) {
                x = x + (int) Math.round(Math.random() * 1000);
                one.append(x);
            }
            System.out.println(one);

            SinglyLinkedIntegerList two = new SinglyLinkedIntegerList();
            for (int i = 0; i < 15; i++) {
                x = x + (int) Math.round(Math.random() * 1000);
                two.append(x);
            }
            System.out.println(two);

            System.out.println(merge(one, two));
        }
    }

}
