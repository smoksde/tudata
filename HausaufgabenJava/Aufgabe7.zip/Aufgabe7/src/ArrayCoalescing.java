import java.lang.Math;
import java.util.Arrays;

public class ArrayCoalescing {

    /**
     * merge merges two int arrays, which are supposed to be sorted in ascending order
     * @param a int array, ascending order
     * @param b int array, ascending order
     * @return the sorted array of the concatenation of a and b
     */

    static int[] merge (int[] a, int[] b){
        int[] res = new int[a.length+b.length];
        int i=0,j=0;
        for(int k=0;k<res.length;k++){
            if (j >= b.length || i<a.length && a[i]<b[j] ){
                res[k] = a[i++];
            } else {
                res[k] = b[j++];
            }
        }
        return res;
    }

    static void swap(int[] a,int i,int j){
        int tmp = a[i];
        a[i] = a[j];
        a[j] = tmp;
    }



    static void randomInit(int[] a){
        for(int i =0;i<a.length;i++){
            a[i] = (int) Math.round(Math.random()*1000);
        }
    }

    static void printArray(int[] a){
        System.out.print("[");
        for(int i =0;i<a.length;i++){
            System.out.print(a[i]+"@"+i);
            if(i<a.length-1)System.out.print(",");
        }

        System.out.println("]");
    }

    public static void main(String[] args) {
        assert(true) : "the world has stopped";

        for(int k = 0; k <1000; k++) {
            int[] a = new int[15];
            randomInit(a);
            Arrays.sort(a);
            printArray(a);

            int[] b = new int[10];

            randomInit(b);
            Arrays.sort(b);
            printArray(b);

            printArray(merge(a, b));
        }
    }
}
