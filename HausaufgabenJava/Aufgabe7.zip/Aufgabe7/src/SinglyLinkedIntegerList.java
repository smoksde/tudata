import java.lang.Math;

public class SinglyLinkedIntegerList {
    private IntegerListEl head = null;

    /**
     * A new IntergerListEl with value i is appended to the list
     * @param i the Interger to be appended
     */
    public void append(Integer i){
        if (head == null) {
            head = new IntegerListEl(null, i);
            return;
        }
        assert(head!=null);
        IntegerListEl el = head;
        while(el.next != null){
            el = el.next;
        }
        el.next = new IntegerListEl(null, i);
    }

    /**
     * getValue returns the value of the list element of the given position
     * @param pos the position of interest
     * @return
     */

    public Integer getValue(int pos){
        for(IntegerListEl el = head; el!= null && pos >=0 ; el=el.next){
            if (pos <= 0){
                return el.val;
            } else {
                --pos;
            }
        }
        return null;
    }


    public String toString(){
        String res = "[";
        for(IntegerListEl e =head; e!=null; e=e.next){
            res = res + e.val + (e.next!=null?", ":"");
        }
        return res+"]";
    }

    /**
     * Inserts the specified value at the specified position in this list,
     * increasing the indices of all values after this index
     *
     * @param index >= 0
     * @param value the value to be added
     */
    public void add(int index, int value){
        //
        // to be implemented
        //

        IntegerListEl here = getEl(index);

        if (here == null) return;
        IntegerListEl elCopy = new IntegerListEl(here.next,here.val);
        here.next = elCopy;
        here.val = value;
    }

    IntegerListEl getEl(int index){

        IntegerListEl res = head;
        for (int i = 0; res!=null && i<index; res = res.next){
            i++;
        }
        return res;

    }


    void insertInOrder(int v){
        IntegerListEl el = head;
        while(el!=null && v>el.val ){
            el = el.next;
        }
        assert (v <= el.val );
        el.insertAfter(new IntegerListEl(el.next,el.val));
        el.val = v;
    }

    void insertionSort(int sortedUntilIndex){
        IntegerListEl fst=null,snd=null;
        if (head!=null) {
            fst = head;
            if (fst.next != null) snd = fst.next;
        }
        if (head == null || snd == null){
            return ;
        } else {
            while (fst.val <= snd.val && snd.next != null){
                fst = snd;
                snd = snd.next;
            }

        }


    }

    public static void main(String[] args) {
        final int size = 15;
        SinglyLinkedIntegerList l = new SinglyLinkedIntegerList();
        for(int i =0;i<size;i++){
            l.append((int) Math.round(Math.random()*1000));
        }
        System.out.println(l);
        System.out.print("[");
        for(int i =size-1;i>=0;i--){
            System.out.print(l.getValue(size-i-1)+(i>0?", ":""));

        }
        System.out.println("]");
    }
}

class IntegerListEl {
    IntegerListEl next;
    Integer val;

    // feel free to add methods

    void insertAfter(IntegerListEl e){
        if (e!= null) {
            e.next = this.next;
            this.next = e;
        } else {
            System.out.println("uh, ooo ... ");
        }
    }

    IntegerListEl(IntegerListEl n, Integer v){
        next = n;
        val = v;
    }

}
