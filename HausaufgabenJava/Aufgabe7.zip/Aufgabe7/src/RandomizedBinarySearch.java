import java.lang.Math;
import java.time.Duration;
import java.util.Arrays;
import java.time.Instant;

public class RandomizedBinarySearch {

    public static Integer search(int[] a, int i){
        Integer res = null;
        if (a.length == 0) return res;
        int l = 0;
        int r = a.length-1;
        int mid = l + (int) Math.round(Math.random() * (r-l));
        assert(l <= mid && mid <= r) ;

        while (a[mid]!= i && r >= l){
            if (a[mid] > i){
                r = mid-1;
                mid = l + (int) Math.round(Math.random() * (r-l));
                assert(l <= mid && mid <= r) ;
            } else {
                assert(a[mid] < i);
                l = mid+1;
                mid = l + (int) Math.round(Math.random() * (r-l));
                assert(l <= mid && mid <= r) ;
            }
        }
        if (a[mid] == i){
            return mid;
        } else {
            return null;
        }
    }

    public static void main(String[] args) {

        int[] a = new int[10000000];

        // wait for user to interrupt
        while(true) {
            for (int i = 0; i < a.length; i++) {
                a[i] = (int) Math.round(Math.random() * 1000000000);
            }

            int i = a[0];

            Arrays.sort(a);

            Instant start;
            Instant finish;
            start = Instant.now();
            Integer x = search(a,i);
            finish = Instant.now();

            Instant begin;
            Instant end;

            begin = Instant.now();
            Integer y = Arrays.binarySearch(a,i);
            end = Instant.now();

            assert(x.equals(y) || x==null) : "x:"+x+" y:"+y;
            System.out.println("randomized takes " + Duration.between(start,finish));
            System.out.println("reference takes  " + Duration.between(begin,end));
        }
    }
}
