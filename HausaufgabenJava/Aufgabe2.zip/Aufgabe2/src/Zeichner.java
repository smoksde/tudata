import de.tub.ise.graphics.Painter;

public class Zeichner {
    public static void main(String[] args) {
        Painter.show();
        for (int y = 0; y < Painter.shroom.length; y++) {
            for (int x = 0; x < Painter.shroom[y].length; x++) {
                Painter.paint(x, y, Painter.shroom[y][x]);
            }
        }
    }
}
