import Prog1Tools.IOTools;

public class VigenereCipher {

    public static void main(String[] args){
        // System.out.println("Das lateinische Alphabet ist " + VigenereCipher.theAlphabet());

        char[][] theSquare = generateVigenereSquare();

        System.out.println("Das Quadrat von Vigenère sieht wie folgt aus: ");
        System.out.print("{");
        for(int i =0;i<26;i++) {
            System.out.print("{");
            for(int j=0; j<26;j++) {
                System.out.print("'"+theSquare[i][j]+"'");
                if (j <25) System.out.print(",");
            }
            System.out.print("}");
            if (i <25) System.out.println(",");
        }
        System.out.println("}");

        // char[] theKey = (IOTools.readString("Bitte einen Schluessel eingeben:")).toCharArray();
        char[] theKey = {'f','o','o','b','a','r'};
        String theMsg = IOTools.readString("Bitte einen Klartext eingeben:");
        System.out.println("Die verschlüsselte Nachricht ist: "+ encryptMsg(theKey,theMsg));


    }

    // theAlphabet is an array of length 26, representing the latin alphabet
    private static char[] theAlphabet = {'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z'};

    /**
     * theAlphabet()
     *
     * @return the latin lower-case alphabet
     */
    public static char[] theAlphabet(){
        char [] result = new char[26];
        for (int i =0; i<26; i++){
            result[i] = (char) (97+i);
        }
        return result;
        // or just do the following
        // return theAlphabet;
    }


    /**
     * shiftLeft(char[],byte) rotates (a copy of) the char-array
     * a positive number of positions to the left
     *
     * @param array the original array
     * @param i the number of positions the array will be shifted
     *          to the left
     * @return a copy of the original array, copied and shifted
     */
    public static char[] shiftLeft(char[] array, byte i) {
        char[] result = new char[array.length];
        i = (byte) (i % array.length);

        assert ((0 <= i) && (i < array.length));

        // move first i entries of the array,
        // producing the rear of the result
        for (int j = 0; j<i; j++){
            result[j+result.length-i] = array[j];
        }
        // move the remaining entries of the array,
        // producing the front of the result
        for (int j = i; j< array.length; j++) {
            result[j-i] = array[j];
        }

        return result;
    }

    /**
     * generateVigenereSquare() generates the Vigenère square.
     *
     * @return the Vigenère square
     */

    public static char[][] generateVigenereSquare(){
        char[][] result = new char[26][];

        for (int i = 0;i<26;i++){
                result[i] = shiftLeft(theAlphabet(), (byte) i);
        }

        return result;
    }

    /**
     * encryptMsg verschlüsselt eine Klartext-Nachricht mit dem Schlüssel.
     *
     * @param key the key of the Vignenère cipher
     * @param msg the message to be encrypted
     * @return the encrypted msg
     */
    public static String encryptMsg(char[] key, String msg){
        char[] cipherText = new char[msg.length()];
        char[][] square = generateVigenereSquare();
        for (int i=0; i < msg.length();i++){
            byte row = (byte) (key[i % key.length] -97);
            byte index = (byte)(((byte) msg.charAt(i))-97);
            cipherText[i] = square[row][index];
        }
        return String.copyValueOf(cipherText);
    }

}
