public class Concatenate {
    public static void main(String[] args){
        String str = "foo";
        char[] arr1 = {'4','2'};
        char[] arr2 = {'b','a','r'};

        System.out.println(concatenate(arr1,arr2));
        System.out.println(concatenate(arr2,arr1));
        System.out.println(concatenate(str,arr1));
        System.out.println(concatenate(str,arr2));
        System.out.println(concatenate(arr1,str));
        System.out.println(concatenate(arr2,str));


    }

    /**
     * concatenate concatenates two char-arrays
     *
     * @param fst a char-array
     * @param snd another char-array
     * @return the concatenation of snd after fst
     */
    public static String concatenate(char[] fst, char[] snd){
        return String.copyValueOf(fst)+String.copyValueOf(snd);
    }

    /**
     * concatenate concatenates a String and a char-array
     *
     * @param fst a String
     * @param snd a char-array
     * @return the concatenation of snd after fst
     *
     */
    public static String concatenate(String fst, char[] snd){
        return fst+String.copyValueOf(snd);
    }


    /**
     * concatenate concatenates a char-array and a String
     *
     * @param fst a char-array
     * @param snd another char-array
     * @return the concatenation of snd after fst
     */
    public static String concatenate(char[] fst, String snd){
        return String.copyValueOf(fst)+snd;
    }


}
