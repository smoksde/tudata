public class HalloWelt {
    public static void main(String[] args) {
        String name = "Heindel";
        String vorname = "Tobias";
        String anrede = "Herr";
        System.out.println("Hallo " + anrede + " "+ name + ", oder darf ich Du sagen " + vorname + "☺?");
    }
}
