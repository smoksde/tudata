/**
 * The top-level class
 */
public class TwodimensionalShape {
    static int nextID = 1;

    int id;
    String color;

    public TwodimensionalShape(){
        id = nextID++;
        color = "black";
    }

}

/**
 * general polygons
 */
class Polygon extends TwodimensionalShape{
    Point[] corners;

    /**
     * the constructor w/o arguments
     */
    public Polygon(){
    }

    /**
     * the constructor for a Polygon from an array of corners and a color
     *
     * @param corners an array of all the corners
     * @param color a color name
     */
    public Polygon(Point[] corners, String color){
        this.id = nextID++;
        this.color = color;
        this.corners = corners;
    }

    /**
     * circumference calculates the circumference of the polygon
     *
     * @return the sum of the lenghts of all sides
     */
    public double circumference(){
        // initialize with the lenght of the "last" side
        double res = Point.distance(corners[0],corners[corners.length-1]);
        for(int i =0; i<corners.length-1;i++){
            Point.distance(corners[i],corners[i+1]);
        }
        return res;
    }

}

/**
 * The subclass of regular polygons
 */
class RegularPolygon extends Polygon{
    /**
     * the constructor with no arguments
     */
    public RegularPolygon(){
    }

    /**
     * the constructor for a regular polygon,
     * using a single side as specification for the whole polygon
     *
     * @param num the number of corners
     * @param fst the first corner
     * @param snd the second corner
     */
    public RegularPolygon(int num, Point fst, Point snd){

        corners = new Point[num];

        // the first two corners are easy
        corners[0] = fst;
        corners[1] = snd;

        // exterior angle, as explained in the assignment
        double exteriorAngle = 2*Math.PI / num;

        // variables and the first values for the distances of coordinates
        double dx = snd.getX() - fst.getX();
        double dy = snd.getY() - fst.getY();
        // the length of the first and all other sides
        double length = Point.distance(fst,snd);

        // the current angle is the angle defined by
        // the first line segment
        // as described in the assignment
        double currentAngle ;
        if (dx > 0 ){
            currentAngle = Math.asin(dy/length);
        } else {
            currentAngle = Math.PI - Math.asin(dy/length);
        }

        // next we add the remaining corners
        for(int i = 2; i < num; i++){
            // setting the angle the next side is defining
            currentAngle = currentAngle - exteriorAngle;
            // updating the resulting deltas of the x and y coordinate, reps.
            dy = length * Math.sin(currentAngle);
            dx = length * Math.cos(currentAngle);
            // the new coordinates are
            double newx = dx + corners[i-1].getX();
            double newy = dy + corners[i-1].getY();
            // storing the new corner
            corners[i] = new Point(newx, newy);
        }

    }

    /**
     * the circumference of a regular polygon given a single side is easy
     *
     * @return n-fold multiplication of the length of the first side
     */
    public double circumference (){
        return corners.length * Point.distance(corners[0],corners[1]);
    }


}

class Circle extends TwodimensionalShape{
    Point center;
    double radius;

    /**
     * the usual constructor
     * @param center the center of the circle
     * @param radius the radius
     * @param color the color
     */
    public Circle(Point center, double radius, String color){
        this.color = color;
        this.id = TwodimensionalShape.nextID++;
        this.center = center;
        this.radius = radius;

    }

    /**
     * the circumference using the usual formula
     *
     * @return the circumference of the circle with the given radius
     */
    public double circumference(){
        return Math.PI*2*radius;
    }


}
