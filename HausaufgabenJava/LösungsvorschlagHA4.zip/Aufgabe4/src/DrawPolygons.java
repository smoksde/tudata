import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.Line2D;
import javax.swing.JFrame;
import javax.swing.SwingUtilities;

/**
 * This program demonstrates how to draw lines using Graphics2D object.
 * @author www.codejava.net
 *
 */
public class DrawPolygons extends JFrame {

    public DrawPolygons() {
        super("Polygon drawing");

        setSize(480, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
    }

    void drawLines(Graphics g, RegularPolygon poly) {


        Graphics2D g2d = (Graphics2D) g;

        // g2d.draw(new Line2D.Double(59.2d, 99.8d, 419.1d, 99.8d));
        // System.out.println("a");
        for(int i =0 ; i < poly.corners.length-1;i++){
            g2d.draw(new Line2D.Double(
                    poly.corners[i].getX(), poly.corners[i].getY(),
                    poly.corners[i+1].getX(), poly.corners[i+1].getY()
            ));
        }
        g2d.draw(new Line2D.Double(
                poly.corners[0].getX(), poly.corners[0].getY(),
                poly.corners[poly.corners.length-1].getX(), poly.corners[poly.corners.length-1].getY()
        ));
        // g2d.drawLine(120, 50, 360, 50);


        //System.out.println("b");

        // g2d.draw(new Line2D.Float(21.50f, 132.50f, 459.50f, 132.50f));

    }

    public void paint(Graphics g) {
        super.paint(g);
        RegularPolygon p = new RegularPolygon(9, new Point(300,300), new Point(350,320));
        drawLines(g, p);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new DrawPolygons().setVisible(true);
            }
        });
    }
}