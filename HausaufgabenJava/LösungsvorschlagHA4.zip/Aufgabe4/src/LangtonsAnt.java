import Prog1Tools.IOTools;

public class LangtonsAnt {

    Position pos;
    int direction;

    static LangtonsAnt ant;
    static char[][] arena;

    public static void main(String[] args) {
        inititialize(
                IOTools.readInt("Bitte geben Sie die Größe des Feldes ein:"),
                IOTools.readInt("Bitte geben Sie die Größe der zufälligen Mitte ein:")
        );

        LangtonsAnt.run();
        printToConsole();

    }

    /**
     * The constructor for an ant.
     *
     * @param p specifies the initial position.
     */
    public LangtonsAnt(Position p) {
        direction = 90;
        pos = p;
    }

    /**
     * getter for the x-position
     *
     * @return the x-position of the ant
     */
    int getX(){
        return pos.x;
    }

    /**
     * getter for the y-position
     *
     * @return the y-position of the ant
     */
    int getY(){
        return pos.y;
    }

    /**
     * the move method updates the direction and the position
     * assuming that the ant "enters" a field that holds the
     * char-value
     *
     * @param nextChar the char of the cell that the ant enters
     */
    void move(char nextChar){
        switch (nextChar){
            case ' ':
                nextChar='X';
                direction = (direction + 90) % 360 ;
                break;
            case 'X':
                nextChar=' ';
                direction = (direction + 270) % 360 ;
                break;
            default:
                System.out.println("Oh no, something went wrong");
                return;
        }
        pos.x = pos.x + deltaX(direction);
        pos.y = pos.y + deltaY(direction);
    }

    /**
     * initialize sets up the arena in which the ant will run around
     *
     * @param big the length of the sides of the quadratic arena
     * @param small the length of the random square in the middle;
     */
    static void inititialize(int big, int small){
        arena = new char[big][big];
        inititalizeWithChar(arena,' ');
        initializeRandomCoreSquare(arena,small);
        ant = new LangtonsAnt(new Position(big/2,big/2));
    }

    /**
     * run() lets the ant run
     */
    static void run(){
        int tmpx;
        int tmpy;
        while(ant.getX() !=-1 && ant.getY() !=-1 && ant.getX()!=arena.length &&  ant.getY()!=arena[arena.length-1].length){
            tmpx = ant.getX();
            tmpy = ant.getY();
            ant.move(arena[tmpx][tmpy]);
            if (arena[tmpx][tmpy] == ' '){
                arena[tmpx][tmpy] = 'X';
            } else {
                arena[tmpx][tmpy] = ' ';
            }
        }
    }


    /**
     * printToConsole outputs the arena to the console
     */
    static void printToConsole(){
        for (int i = 0; i < arena.length; i++) {
            System.out.println(arena[i]);
        }
    }

    /**
     * deltaX computes the change of the x-coordinate obtained by going
     * one step in the given direction
     *
     * @param degree a direction in degree
     * @return the change of the x-coordinate that results from going one step into direction degree
     */
    static int deltaX(int degree){
        if (degree == 0){
            return 1;
        }
        if (degree == 180){
            return -1;
        }
        return 0;
    }


    /**
     * deltaY computes the change of the y-coordinate obtained by going
     * one step in the given direction
     *
     * @param degree a direction in degree
     * @return the change of the y-coordinate that results from going one step into direction degree
     */
    static int deltaY(int degree){
        if (degree == 90){
            return 1;
        }
        if (degree == 270){
            return -1;
        }
        return 0;
    }

    /**
     * intitializeWithChar writes the given char in all array cells
     *
     * @param a the char array to initialize with
     * @param c a character
     */
    static void inititalizeWithChar(char[][] a, char c){
        for(int i=0;i<a.length;i++){
            for(int j=0;j<a[i].length;j++){
                a[i][j] = c;
            }
        }
    }

    /**
     * initializeRandomCoreSquare initializes a square in the middle of
     * a given rectangular array whose sides are given by the second parameter
     * the two options for the character being ' ' or 'X'
     *
     * @param a a rectangular array of char values
     * @param width the width of the square to be initialized randomly
     */
    static void initializeRandomCoreSquare(char[][] a, int width){
        int upperRow = a.length/2 - width/2;
        int leftColumn = a[upperRow].length/2 - width/2;
        for(int i=0;i<width;i++){
            for(int j=0;j<width;j++){
                if (Math.random() <0.5){
                    a[i+upperRow][j+leftColumn] = ' ';
                } else {
                    a[i+upperRow][j+leftColumn] = 'X';
                }
            }
        }

    }
}

