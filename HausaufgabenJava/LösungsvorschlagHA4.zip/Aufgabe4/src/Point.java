public class Point {
    private double x;
    private double y;

    public Point(double x, double y){
        this.x =x;
        this.y =y;
    }

    public double getX(){
        return this.x;
    }
    public double getY(){
        return this.y;
    }

    /*
    further helper methods etc. below
     */

    public static double distance(Point a, Point b){
        double dx = a.getX() - b.getX();
        double dy = a.getY() - b.getY();
        return Math.sqrt( dx*dx +dy*dy);
    }
}
