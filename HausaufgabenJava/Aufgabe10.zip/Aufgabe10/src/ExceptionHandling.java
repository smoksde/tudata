import java.util.Arrays;
import java.util.LinkedList;

public class ExceptionHandling{

    public static LinkedList listFlatten(LinkedList l){
        LinkedList res = new LinkedList();
        for (Object x :l) {
            try {
                System.out.println(x);
                res.addAll((LinkedList)x);
            } catch (NullPointerException e) {
                System.err.println("Ignoring Null-object.");
            } catch (ClassCastException e) {
                System.err.println("Ignoring non-list + "+x+".");
            }
        }
        return res;
    }

    public static double mean(Integer[] a, int i, int j){
        int sum = 0;
        for(int k= i; k<=j;k++){
            try {
                sum = sum + a[k];
            } catch (NullPointerException e){
                i++;
                System.err.println("Ignoring Null-object");
            } catch (ArrayIndexOutOfBoundsException e){
                System.err.println("The upper index is beyond the limits.");
                j = a.length-1;
                break;
            }
        }
        try {
            return sum / (1 + j - i);
        } catch (ArithmeticException e){
            if ((1 + j - i) == 0){
                System.err.println("Means don't make sense for empty parts.");
            } else {
                throw e;
            }
            return 0;
        }
    }

    public static void main(String[] args) {
        Integer[] ints = {1,2,3};
        LinkedList l = new LinkedList();
        l.add(null);
        for(Integer i : Arrays.asList(ints)) l.add(i);
        l = listFlatten(l);

        System.out.println(mean(ints,2,4));
        System.out.println(mean(ints,2,2));
        ints[2] = null;
        System.out.println(mean(ints,0,2));
    }
}


