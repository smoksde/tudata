public class BubbleSort {

    static void bubbleSort(int arr[]) {
        int n = arr.length;
        for (int i = 0; i < n - 1; i++)
            for (int j = 0; j < n - i - 1; j++)
                if (arr[j] > arr[j + 1]) {
                    // swap temp and arr[i]
                    int temp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;
                }
    }

    static Boolean sorted(int[] arr){
        Boolean res = true;
        for(int i=0;i<arr.length-1;res = res & (arr[i]<= arr[++i]));
        return res;
    }

    public static void main(String[] args) {
        int[] x = new int[100];
        Thread[] threads = new Thread[x.length/10];

        do {
            for(int i=0;i<x.length;i++)
                x[i] = (int) (x.length*java.lang.Math.random());
            for (int i = 0; i < threads.length; i++) {
                threads[i] = new Bubbler(x);
            }
            for (int i = 0; i < threads.length; i++) {
                threads[i].start();
            }
        } while(sorted(x));
        System.out.println("oops");
    }
}

class Bubbler extends Thread{
    int[] theArray = null;

    Bubbler(int[]a){
        theArray=a;
    }
    public void run(){
        BubbleSort.bubbleSort(theArray);
        System.out.println(this+" has run.");
    }
}
