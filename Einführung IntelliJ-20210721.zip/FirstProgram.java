public class FirstProgram {

	public static void main(String[] args) {
		System.out.println("Congratulations, you have successfully executed your first java program!");

	}

}
